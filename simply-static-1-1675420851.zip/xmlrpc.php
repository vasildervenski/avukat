<!DOCTYPE html>
<html>
	<head>
		<title>Redirecting...</title>
		<meta http-equiv="refresh" content="0;url=/avukat/?simply_static_page=109">
	</head>
	<body>
		<script type="text/javascript">
			window.location = "/avukat/?simply_static_page=109";
		</script>

		<p>You are being redirected to <a href="/avukat/?simply_static_page=109">/avukat/?simply_static_page=109</a></p>
	</body>
</html>
